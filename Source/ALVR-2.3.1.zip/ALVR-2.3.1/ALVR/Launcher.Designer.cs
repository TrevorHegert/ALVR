﻿namespace ALVR
{
    partial class Launcher
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Launcher));
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.metroButton2 = new MetroFramework.Controls.MetroButton();
            this.metroProgressSpinner1 = new MetroFramework.Controls.MetroProgressSpinner();
            this.captureComposedDDSButton = new MetroFramework.Controls.MetroButton();
            this.metroTabControl1 = new MetroFramework.Controls.MetroTabControl();
            this.serverTab = new MetroFramework.Controls.MetroTabPage();
            this.findingPanel = new MetroFramework.Controls.MetroPanel();
            this.noClientLabel = new MetroFramework.Controls.MetroLabel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.NameColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AddressColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.refreshRateColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Button = new System.Windows.Forms.DataGridViewButtonColumn();
            this.metroProgressSpinner2 = new MetroFramework.Controls.MetroProgressSpinner();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.connectedPanel = new MetroFramework.Controls.MetroPanel();
            this.autoConnectCheckBox = new MetroFramework.Controls.MetroCheckBox();
            this.statDataGridView = new System.Windows.Forms.DataGridView();
            this.Name1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Value1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.disconnectButton = new MetroFramework.Controls.MetroButton();
            this.connectedLabel = new MetroFramework.Controls.MetroLabel();
            this.messagePanel = new MetroFramework.Controls.MetroPanel();
            this.messageLabel = new MetroFramework.Controls.MetroLabel();
            this.controllerTab = new MetroFramework.Controls.MetroTabPage();
            this.enableControllerCheckBox = new MetroFramework.Controls.MetroCheckBox();
            this.metroLabel32 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel22 = new MetroFramework.Controls.MetroLabel();
            this.recenterButtonComboBox = new MetroFramework.Controls.MetroComboBox();
            this.backComboBox = new MetroFramework.Controls.MetroComboBox();
            this.trackpadClickComboBox = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel33 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel23 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel20 = new MetroFramework.Controls.MetroLabel();
            this.triggerComboBox = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel21 = new MetroFramework.Controls.MetroLabel();
            this.videoTab = new MetroFramework.Controls.MetroTabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.metroLabel13 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel19 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel12 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.codecComboBox = new MetroFramework.Controls.MetroComboBox();
            this.resolutionComboBox = new MetroFramework.Controls.MetroComboBox();
            this.resolutionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bufferLabel = new MetroFramework.Controls.MetroLabel();
            this.bitrateLabel = new MetroFramework.Controls.MetroLabel();
            this.metroLabel18 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel17 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel16 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel31 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.bufferTrackBar = new MetroFramework.Controls.MetroTrackBar();
            this.bitrateTrackBar = new MetroFramework.Controls.MetroTrackBar();
            this.soundTab = new MetroFramework.Controls.MetroTabPage();
            this.soundDeviceComboBox = new MetroFramework.Controls.MetroComboBox();
            this.soundCheckBox = new MetroFramework.Controls.MetroCheckBox();
            this.otherTab = new MetroFramework.Controls.MetroTabPage();
            this.trackingFrameOffsetTextBox = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel30 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel29 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel28 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel27 = new MetroFramework.Controls.MetroLabel();
            this.refDisconnectCommandButton = new MetroFramework.Controls.MetroButton();
            this.refConnectCommandButton = new MetroFramework.Controls.MetroButton();
            this.disconnectCommandTextBox = new MetroFramework.Controls.MetroTextBox();
            this.connectCommandTextBox = new MetroFramework.Controls.MetroTextBox();
            this.offsetPosCheckBox = new MetroFramework.Controls.MetroCheckBox();
            this.offsetPosZTextBox = new MetroFramework.Controls.MetroTextBox();
            this.offsetPosYTextBox = new MetroFramework.Controls.MetroTextBox();
            this.offsetPosXTextBox = new MetroFramework.Controls.MetroTextBox();
            this.saveTrackingFrameOffsetButton = new MetroFramework.Controls.MetroButton();
            this.sendOffsetPos = new MetroFramework.Controls.MetroButton();
            this.metroLabel26 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel25 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel24 = new MetroFramework.Controls.MetroLabel();
            this.suppressFrameDropCheckBox = new MetroFramework.Controls.MetroCheckBox();
            this.onlySteamVRCheckBox = new MetroFramework.Controls.MetroCheckBox();
            this.fakeTrackingReferenceCheckBox = new MetroFramework.Controls.MetroCheckBox();
            this.debugTab = new MetroFramework.Controls.MetroTabPage();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.logText = new MetroFramework.Controls.MetroTextBox();
            this.metroCheckBox3 = new MetroFramework.Controls.MetroCheckBox();
            this.metroCheckBox2 = new MetroFramework.Controls.MetroCheckBox();
            this.debugCaptureOutputCheckBox = new MetroFramework.Controls.MetroCheckBox();
            this.debugLogCheckBox = new MetroFramework.Controls.MetroCheckBox();
            this.metroCheckBox1 = new MetroFramework.Controls.MetroCheckBox();
            this.metroTextBox2 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox1 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroButton5 = new MetroFramework.Controls.MetroButton();
            this.packetlossButton = new MetroFramework.Controls.MetroButton();
            this.metroButton4 = new MetroFramework.Controls.MetroButton();
            this.captureLayerDDSButton = new MetroFramework.Controls.MetroButton();
            this.aboutTab = new MetroFramework.Controls.MetroTabPage();
            this.driverLabel = new MetroFramework.Controls.MetroLabel();
            this.uninstallButton = new MetroFramework.Controls.MetroButton();
            this.listDriversButton = new MetroFramework.Controls.MetroButton();
            this.installButton = new MetroFramework.Controls.MetroButton();
            this.metroLabel15 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel14 = new MetroFramework.Controls.MetroLabel();
            this.licenseTextBox = new MetroFramework.Controls.MetroTextBox();
            this.versionLabel = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.startServerButton = new MetroFramework.Controls.MetroButton();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.defaultSoundDeviceCheckBox = new MetroFramework.Controls.MetroCheckBox();
            this.metroTabControl1.SuspendLayout();
            this.serverTab.SuspendLayout();
            this.findingPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.connectedPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.statDataGridView)).BeginInit();
            this.messagePanel.SuspendLayout();
            this.controllerTab.SuspendLayout();
            this.videoTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.resolutionBindingSource)).BeginInit();
            this.soundTab.SuspendLayout();
            this.otherTab.SuspendLayout();
            this.debugTab.SuspendLayout();
            this.aboutTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // metroButton1
            // 
            this.metroButton1.Location = new System.Drawing.Point(281, 63);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(75, 23);
            this.metroButton1.TabIndex = 6;
            this.metroButton1.Text = "Send";
            this.metroButton1.Click += new System.EventHandler(this.button2_Click);
            // 
            // metroButton2
            // 
            this.metroButton2.Location = new System.Drawing.Point(281, 104);
            this.metroButton2.Name = "metroButton2";
            this.metroButton2.Size = new System.Drawing.Size(75, 23);
            this.metroButton2.TabIndex = 6;
            this.metroButton2.Text = "Send";
            this.metroButton2.Click += new System.EventHandler(this.button3_Click);
            // 
            // metroProgressSpinner1
            // 
            this.metroProgressSpinner1.Location = new System.Drawing.Point(473, 32);
            this.metroProgressSpinner1.Maximum = 100;
            this.metroProgressSpinner1.Name = "metroProgressSpinner1";
            this.metroProgressSpinner1.Size = new System.Drawing.Size(38, 36);
            this.metroProgressSpinner1.TabIndex = 7;
            this.metroProgressSpinner1.Value = 30;
            // 
            // captureComposedDDSButton
            // 
            this.captureComposedDDSButton.Location = new System.Drawing.Point(258, 148);
            this.captureComposedDDSButton.Name = "captureComposedDDSButton";
            this.captureComposedDDSButton.Size = new System.Drawing.Size(98, 23);
            this.captureComposedDDSButton.TabIndex = 6;
            this.captureComposedDDSButton.Text = "Capture Comp.";
            this.captureComposedDDSButton.Click += new System.EventHandler(this.captureComposedDDSButton_Click);
            // 
            // metroTabControl1
            // 
            this.metroTabControl1.Controls.Add(this.serverTab);
            this.metroTabControl1.Controls.Add(this.controllerTab);
            this.metroTabControl1.Controls.Add(this.videoTab);
            this.metroTabControl1.Controls.Add(this.soundTab);
            this.metroTabControl1.Controls.Add(this.otherTab);
            this.metroTabControl1.Controls.Add(this.debugTab);
            this.metroTabControl1.Controls.Add(this.aboutTab);
            this.metroTabControl1.Location = new System.Drawing.Point(23, 63);
            this.metroTabControl1.Name = "metroTabControl1";
            this.metroTabControl1.SelectedIndex = 3;
            this.metroTabControl1.Size = new System.Drawing.Size(664, 396);
            this.metroTabControl1.TabIndex = 8;
            // 
            // serverTab
            // 
            this.serverTab.Controls.Add(this.findingPanel);
            this.serverTab.Controls.Add(this.connectedPanel);
            this.serverTab.Controls.Add(this.messagePanel);
            this.serverTab.HorizontalScrollbarBarColor = true;
            this.serverTab.Location = new System.Drawing.Point(4, 38);
            this.serverTab.Name = "serverTab";
            this.serverTab.Size = new System.Drawing.Size(656, 354);
            this.serverTab.TabIndex = 3;
            this.serverTab.Text = "Server";
            this.serverTab.VerticalScrollbarBarColor = true;
            // 
            // findingPanel
            // 
            this.findingPanel.Controls.Add(this.noClientLabel);
            this.findingPanel.Controls.Add(this.dataGridView1);
            this.findingPanel.Controls.Add(this.metroProgressSpinner2);
            this.findingPanel.Controls.Add(this.metroLabel4);
            this.findingPanel.HorizontalScrollbarBarColor = true;
            this.findingPanel.HorizontalScrollbarHighlightOnWheel = false;
            this.findingPanel.HorizontalScrollbarSize = 10;
            this.findingPanel.Location = new System.Drawing.Point(3, 0);
            this.findingPanel.Name = "findingPanel";
            this.findingPanel.Size = new System.Drawing.Size(657, 351);
            this.findingPanel.TabIndex = 11;
            this.findingPanel.VerticalScrollbarBarColor = true;
            this.findingPanel.VerticalScrollbarHighlightOnWheel = false;
            this.findingPanel.VerticalScrollbarSize = 10;
            // 
            // noClientLabel
            // 
            this.noClientLabel.AutoSize = true;
            this.noClientLabel.Location = new System.Drawing.Point(79, 105);
            this.noClientLabel.Name = "noClientLabel";
            this.noClientLabel.Size = new System.Drawing.Size(292, 76);
            this.noClientLabel.TabIndex = 10;
            this.noClientLabel.Text = "Headset not found.\r\n\r\nMake sure the client is launched.\r\nOr check the firewall se" +
    "ttings (permit UDP/9944).";
            this.noClientLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.ColumnHeadersVisible = false;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.NameColumn,
            this.AddressColumn,
            this.refreshRateColumn,
            this.Button});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.Location = new System.Drawing.Point(29, 28);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.RowHeadersVisible = false;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView1.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.dataGridView1.RowTemplate.Height = 40;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(392, 302);
            this.dataGridView1.TabIndex = 2;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // NameColumn
            // 
            this.NameColumn.HeaderText = "Name";
            this.NameColumn.Name = "NameColumn";
            this.NameColumn.ReadOnly = true;
            // 
            // AddressColumn
            // 
            this.AddressColumn.HeaderText = "IPAddress";
            this.AddressColumn.Name = "AddressColumn";
            this.AddressColumn.ReadOnly = true;
            // 
            // refreshRateColumn
            // 
            this.refreshRateColumn.HeaderText = "Hz";
            this.refreshRateColumn.Name = "refreshRateColumn";
            this.refreshRateColumn.ReadOnly = true;
            this.refreshRateColumn.Width = 55;
            // 
            // Button
            // 
            this.Button.HeaderText = "Button";
            this.Button.Name = "Button";
            this.Button.ReadOnly = true;
            this.Button.Text = "Connect";
            this.Button.Width = 135;
            // 
            // metroProgressSpinner2
            // 
            this.metroProgressSpinner2.Location = new System.Drawing.Point(443, 159);
            this.metroProgressSpinner2.Maximum = 100;
            this.metroProgressSpinner2.Name = "metroProgressSpinner2";
            this.metroProgressSpinner2.Size = new System.Drawing.Size(38, 36);
            this.metroProgressSpinner2.TabIndex = 7;
            this.metroProgressSpinner2.Value = 70;
            // 
            // metroLabel4
            // 
            this.metroLabel4.BackColor = System.Drawing.Color.White;
            this.metroLabel4.CustomBackground = true;
            this.metroLabel4.CustomForeColor = true;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel4.Location = new System.Drawing.Point(487, 159);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(156, 39);
            this.metroLabel4.TabIndex = 9;
            this.metroLabel4.Text = "Finding Headset...";
            this.metroLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // connectedPanel
            // 
            this.connectedPanel.Controls.Add(this.autoConnectCheckBox);
            this.connectedPanel.Controls.Add(this.statDataGridView);
            this.connectedPanel.Controls.Add(this.disconnectButton);
            this.connectedPanel.Controls.Add(this.connectedLabel);
            this.connectedPanel.HorizontalScrollbarBarColor = true;
            this.connectedPanel.HorizontalScrollbarHighlightOnWheel = false;
            this.connectedPanel.HorizontalScrollbarSize = 10;
            this.connectedPanel.Location = new System.Drawing.Point(3, 3);
            this.connectedPanel.Name = "connectedPanel";
            this.connectedPanel.Size = new System.Drawing.Size(657, 351);
            this.connectedPanel.TabIndex = 11;
            this.connectedPanel.VerticalScrollbarBarColor = true;
            this.connectedPanel.VerticalScrollbarHighlightOnWheel = false;
            this.connectedPanel.VerticalScrollbarSize = 10;
            // 
            // autoConnectCheckBox
            // 
            this.autoConnectCheckBox.AutoSize = true;
            this.autoConnectCheckBox.Location = new System.Drawing.Point(73, 204);
            this.autoConnectCheckBox.Name = "autoConnectCheckBox";
            this.autoConnectCheckBox.Size = new System.Drawing.Size(147, 15);
            this.autoConnectCheckBox.TabIndex = 13;
            this.autoConnectCheckBox.Text = "Auto connect next time";
            this.autoConnectCheckBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.autoConnectCheckBox.UseVisualStyleBackColor = true;
            this.autoConnectCheckBox.CheckedChanged += new System.EventHandler(this.autoConnectCheckBox_CheckedChanged);
            // 
            // statDataGridView
            // 
            this.statDataGridView.AllowUserToAddRows = false;
            this.statDataGridView.AllowUserToDeleteRows = false;
            this.statDataGridView.BackgroundColor = System.Drawing.Color.White;
            this.statDataGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.statDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.statDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.statDataGridView.ColumnHeadersVisible = false;
            this.statDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Name1,
            this.Value1});
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.statDataGridView.DefaultCellStyle = dataGridViewCellStyle6;
            this.statDataGridView.Location = new System.Drawing.Point(282, 28);
            this.statDataGridView.Name = "statDataGridView";
            this.statDataGridView.ReadOnly = true;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.statDataGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.statDataGridView.RowHeadersVisible = false;
            this.statDataGridView.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.White;
            this.statDataGridView.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.statDataGridView.RowTemplate.Height = 21;
            this.statDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.statDataGridView.Size = new System.Drawing.Size(352, 299);
            this.statDataGridView.TabIndex = 12;
            // 
            // Name1
            // 
            this.Name1.HeaderText = "Column1";
            this.Name1.Name = "Name1";
            this.Name1.ReadOnly = true;
            this.Name1.Width = 160;
            // 
            // Value1
            // 
            this.Value1.HeaderText = "Column1";
            this.Value1.Name = "Value1";
            this.Value1.ReadOnly = true;
            this.Value1.Width = 160;
            // 
            // disconnectButton
            // 
            this.disconnectButton.Location = new System.Drawing.Point(91, 241);
            this.disconnectButton.Name = "disconnectButton";
            this.disconnectButton.Size = new System.Drawing.Size(113, 40);
            this.disconnectButton.TabIndex = 11;
            this.disconnectButton.Text = "Disconnect";
            this.disconnectButton.Click += new System.EventHandler(this.disconnectButton_Click);
            // 
            // connectedLabel
            // 
            this.connectedLabel.BackColor = System.Drawing.Color.White;
            this.connectedLabel.CustomBackground = true;
            this.connectedLabel.CustomForeColor = true;
            this.connectedLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.connectedLabel.Location = new System.Drawing.Point(64, 67);
            this.connectedLabel.Name = "connectedLabel";
            this.connectedLabel.Size = new System.Drawing.Size(156, 92);
            this.connectedLabel.TabIndex = 9;
            this.connectedLabel.Text = "Client connected.\r\nDevice Name\r\nIP Address:port\r\n";
            this.connectedLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // messagePanel
            // 
            this.messagePanel.Controls.Add(this.messageLabel);
            this.messagePanel.HorizontalScrollbarBarColor = true;
            this.messagePanel.HorizontalScrollbarHighlightOnWheel = false;
            this.messagePanel.HorizontalScrollbarSize = 10;
            this.messagePanel.Location = new System.Drawing.Point(3, 3);
            this.messagePanel.Name = "messagePanel";
            this.messagePanel.Size = new System.Drawing.Size(657, 351);
            this.messagePanel.TabIndex = 10;
            this.messagePanel.VerticalScrollbarBarColor = true;
            this.messagePanel.VerticalScrollbarHighlightOnWheel = false;
            this.messagePanel.VerticalScrollbarSize = 10;
            // 
            // messageLabel
            // 
            this.messageLabel.BackColor = System.Drawing.Color.White;
            this.messageLabel.CustomBackground = true;
            this.messageLabel.CustomForeColor = true;
            this.messageLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.messageLabel.Location = new System.Drawing.Point(161, 93);
            this.messageLabel.Name = "messageLabel";
            this.messageLabel.Size = new System.Drawing.Size(335, 75);
            this.messageLabel.TabIndex = 9;
            this.messageLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // controllerTab
            // 
            this.controllerTab.Controls.Add(this.enableControllerCheckBox);
            this.controllerTab.Controls.Add(this.metroLabel32);
            this.controllerTab.Controls.Add(this.metroLabel22);
            this.controllerTab.Controls.Add(this.recenterButtonComboBox);
            this.controllerTab.Controls.Add(this.backComboBox);
            this.controllerTab.Controls.Add(this.trackpadClickComboBox);
            this.controllerTab.Controls.Add(this.metroLabel33);
            this.controllerTab.Controls.Add(this.metroLabel23);
            this.controllerTab.Controls.Add(this.metroLabel20);
            this.controllerTab.Controls.Add(this.triggerComboBox);
            this.controllerTab.Controls.Add(this.metroLabel21);
            this.controllerTab.HorizontalScrollbarBarColor = true;
            this.controllerTab.Location = new System.Drawing.Point(4, 38);
            this.controllerTab.Name = "controllerTab";
            this.controllerTab.Size = new System.Drawing.Size(656, 354);
            this.controllerTab.TabIndex = 6;
            this.controllerTab.Text = "Controller";
            this.controllerTab.VerticalScrollbarBarColor = true;
            // 
            // enableControllerCheckBox
            // 
            this.enableControllerCheckBox.AutoSize = true;
            this.enableControllerCheckBox.Checked = global::ALVR.Properties.Settings.Default.enableController;
            this.enableControllerCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.enableControllerCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("Checked", global::ALVR.Properties.Settings.Default, "enableController", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.enableControllerCheckBox.Location = new System.Drawing.Point(36, 33);
            this.enableControllerCheckBox.Name = "enableControllerCheckBox";
            this.enableControllerCheckBox.Size = new System.Drawing.Size(112, 15);
            this.enableControllerCheckBox.TabIndex = 11;
            this.enableControllerCheckBox.Text = "Enable controller";
            this.enableControllerCheckBox.UseVisualStyleBackColor = true;
            this.enableControllerCheckBox.CheckedChanged += new System.EventHandler(this.enableControllerCheckBox_CheckedChanged);
            // 
            // metroLabel32
            // 
            this.metroLabel32.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel32.AutoSize = true;
            this.metroLabel32.Location = new System.Drawing.Point(462, -697);
            this.metroLabel32.Name = "metroLabel32";
            this.metroLabel32.Size = new System.Drawing.Size(162, 38);
            this.metroLabel32.TabIndex = 10;
            this.metroLabel32.Text = "If FreePIE plugin is used,\r\nthese settings are ignored.";
            // 
            // metroLabel22
            // 
            this.metroLabel22.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.metroLabel22.AutoSize = true;
            this.metroLabel22.Location = new System.Drawing.Point(216, -301);
            this.metroLabel22.Name = "metroLabel22";
            this.metroLabel22.Size = new System.Drawing.Size(240, 38);
            this.metroLabel22.TabIndex = 10;
            this.metroLabel22.Text = "These settings will be applied instantly\r\nexcept for enabling/disabling controlle" +
    "r.";
            // 
            // recenterButtonComboBox
            // 
            this.recenterButtonComboBox.FormattingEnabled = true;
            this.recenterButtonComboBox.ItemHeight = 23;
            this.recenterButtonComboBox.Location = new System.Drawing.Point(216, 214);
            this.recenterButtonComboBox.Name = "recenterButtonComboBox";
            this.recenterButtonComboBox.Size = new System.Drawing.Size(192, 29);
            this.recenterButtonComboBox.TabIndex = 9;
            this.recenterButtonComboBox.SelectedIndexChanged += new System.EventHandler(this.recenterButtonComboBox_SelectedIndexChanged);
            // 
            // backComboBox
            // 
            this.backComboBox.FormattingEnabled = true;
            this.backComboBox.ItemHeight = 23;
            this.backComboBox.Location = new System.Drawing.Point(216, 167);
            this.backComboBox.Name = "backComboBox";
            this.backComboBox.Size = new System.Drawing.Size(192, 29);
            this.backComboBox.TabIndex = 9;
            this.backComboBox.SelectedIndexChanged += new System.EventHandler(this.backClickComboBox_SelectedIndexChanged);
            // 
            // trackpadClickComboBox
            // 
            this.trackpadClickComboBox.FormattingEnabled = true;
            this.trackpadClickComboBox.ItemHeight = 23;
            this.trackpadClickComboBox.Location = new System.Drawing.Point(216, 122);
            this.trackpadClickComboBox.Name = "trackpadClickComboBox";
            this.trackpadClickComboBox.Size = new System.Drawing.Size(192, 29);
            this.trackpadClickComboBox.TabIndex = 9;
            this.trackpadClickComboBox.SelectedIndexChanged += new System.EventHandler(this.trackpadClickComboBox_SelectedIndexChanged);
            // 
            // metroLabel33
            // 
            this.metroLabel33.AutoSize = true;
            this.metroLabel33.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel33.Location = new System.Drawing.Point(56, 167);
            this.metroLabel33.Name = "metroLabel33";
            this.metroLabel33.Size = new System.Drawing.Size(47, 25);
            this.metroLabel33.TabIndex = 8;
            this.metroLabel33.Text = "Back";
            // 
            // metroLabel23
            // 
            this.metroLabel23.AutoSize = true;
            this.metroLabel23.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel23.Location = new System.Drawing.Point(56, 214);
            this.metroLabel23.Name = "metroLabel23";
            this.metroLabel23.Size = new System.Drawing.Size(133, 25);
            this.metroLabel23.TabIndex = 8;
            this.metroLabel23.Text = "Recenter button";
            // 
            // metroLabel20
            // 
            this.metroLabel20.AutoSize = true;
            this.metroLabel20.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel20.Location = new System.Drawing.Point(56, 122);
            this.metroLabel20.Name = "metroLabel20";
            this.metroLabel20.Size = new System.Drawing.Size(116, 25);
            this.metroLabel20.TabIndex = 8;
            this.metroLabel20.Text = "Trackpad click";
            // 
            // triggerComboBox
            // 
            this.triggerComboBox.FormattingEnabled = true;
            this.triggerComboBox.ItemHeight = 23;
            this.triggerComboBox.Location = new System.Drawing.Point(216, 71);
            this.triggerComboBox.Name = "triggerComboBox";
            this.triggerComboBox.Size = new System.Drawing.Size(192, 29);
            this.triggerComboBox.TabIndex = 9;
            this.triggerComboBox.SelectedIndexChanged += new System.EventHandler(this.triggerComboBox_SelectedIndexChanged);
            // 
            // metroLabel21
            // 
            this.metroLabel21.AutoSize = true;
            this.metroLabel21.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel21.Location = new System.Drawing.Point(56, 71);
            this.metroLabel21.Name = "metroLabel21";
            this.metroLabel21.Size = new System.Drawing.Size(64, 25);
            this.metroLabel21.TabIndex = 8;
            this.metroLabel21.Text = "Trigger";
            // 
            // videoTab
            // 
            this.videoTab.Controls.Add(this.label3);
            this.videoTab.Controls.Add(this.label2);
            this.videoTab.Controls.Add(this.label1);
            this.videoTab.Controls.Add(this.metroLabel13);
            this.videoTab.Controls.Add(this.metroLabel19);
            this.videoTab.Controls.Add(this.metroLabel12);
            this.videoTab.Controls.Add(this.metroLabel11);
            this.videoTab.Controls.Add(this.codecComboBox);
            this.videoTab.Controls.Add(this.resolutionComboBox);
            this.videoTab.Controls.Add(this.bufferLabel);
            this.videoTab.Controls.Add(this.bitrateLabel);
            this.videoTab.Controls.Add(this.metroLabel18);
            this.videoTab.Controls.Add(this.metroLabel9);
            this.videoTab.Controls.Add(this.metroLabel17);
            this.videoTab.Controls.Add(this.metroLabel8);
            this.videoTab.Controls.Add(this.metroLabel16);
            this.videoTab.Controls.Add(this.metroLabel10);
            this.videoTab.Controls.Add(this.metroLabel31);
            this.videoTab.Controls.Add(this.metroLabel7);
            this.videoTab.Controls.Add(this.bufferTrackBar);
            this.videoTab.Controls.Add(this.bitrateTrackBar);
            this.videoTab.HorizontalScrollbarBarColor = true;
            this.videoTab.Location = new System.Drawing.Point(4, 38);
            this.videoTab.Name = "videoTab";
            this.videoTab.Size = new System.Drawing.Size(656, 354);
            this.videoTab.TabIndex = 5;
            this.videoTab.Text = "Video";
            this.videoTab.VerticalScrollbarBarColor = true;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.DarkGray;
            this.label3.Location = new System.Drawing.Point(29, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(600, 1);
            this.label3.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.DarkGray;
            this.label2.Location = new System.Drawing.Point(29, 234);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(600, 1);
            this.label2.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.DarkGray;
            this.label1.Location = new System.Drawing.Point(29, 149);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(600, 1);
            this.label1.TabIndex = 8;
            // 
            // metroLabel13
            // 
            this.metroLabel13.AutoSize = true;
            this.metroLabel13.Location = new System.Drawing.Point(171, 313);
            this.metroLabel13.Name = "metroLabel13";
            this.metroLabel13.Size = new System.Drawing.Size(292, 19);
            this.metroLabel13.TabIndex = 7;
            this.metroLabel13.Text = "These settings will be applied after restart server.";
            // 
            // metroLabel19
            // 
            this.metroLabel19.AutoSize = true;
            this.metroLabel19.Location = new System.Drawing.Point(56, 284);
            this.metroLabel19.Name = "metroLabel19";
            this.metroLabel19.Size = new System.Drawing.Size(558, 19);
            this.metroLabel19.TabIndex = 7;
            this.metroLabel19.Text = "Buffer size on client side. 200kB is recommended. If you experience packet loss, " +
    "enlarge buffer.";
            // 
            // metroLabel12
            // 
            this.metroLabel12.AutoSize = true;
            this.metroLabel12.Location = new System.Drawing.Point(56, 195);
            this.metroLabel12.Name = "metroLabel12";
            this.metroLabel12.Size = new System.Drawing.Size(356, 19);
            this.metroLabel12.TabIndex = 7;
            this.metroLabel12.Text = "Resolution of video streaming. 2048x1024 is recommended.";
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.Location = new System.Drawing.Point(56, 118);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(321, 19);
            this.metroLabel11.TabIndex = 7;
            this.metroLabel11.Text = "Bitrate of video streaming. 30Mbps is recommended.";
            // 
            // codecComboBox
            // 
            this.codecComboBox.FormattingEnabled = true;
            this.codecComboBox.ItemHeight = 23;
            this.codecComboBox.Location = new System.Drawing.Point(185, 13);
            this.codecComboBox.Name = "codecComboBox";
            this.codecComboBox.Size = new System.Drawing.Size(192, 29);
            this.codecComboBox.TabIndex = 6;
            // 
            // resolutionComboBox
            // 
            this.resolutionComboBox.DataSource = this.resolutionBindingSource;
            this.resolutionComboBox.DisplayMember = "display";
            this.resolutionComboBox.FormattingEnabled = true;
            this.resolutionComboBox.ItemHeight = 23;
            this.resolutionComboBox.Location = new System.Drawing.Point(185, 163);
            this.resolutionComboBox.Name = "resolutionComboBox";
            this.resolutionComboBox.Size = new System.Drawing.Size(192, 29);
            this.resolutionComboBox.TabIndex = 6;
            this.resolutionComboBox.ValueMember = "width";
            // 
            // resolutionBindingSource
            // 
            this.resolutionBindingSource.DataSource = typeof(ALVR.ServerConfig.Resolution);
            // 
            // bufferLabel
            // 
            this.bufferLabel.AutoSize = true;
            this.bufferLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.bufferLabel.Location = new System.Drawing.Point(559, 258);
            this.bufferLabel.Name = "bufferLabel";
            this.bufferLabel.Size = new System.Drawing.Size(57, 25);
            this.bufferLabel.TabIndex = 5;
            this.bufferLabel.Text = "200kB";
            // 
            // bitrateLabel
            // 
            this.bitrateLabel.AutoSize = true;
            this.bitrateLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.bitrateLabel.Location = new System.Drawing.Point(559, 86);
            this.bitrateLabel.Name = "bitrateLabel";
            this.bitrateLabel.Size = new System.Drawing.Size(72, 25);
            this.bitrateLabel.TabIndex = 5;
            this.bitrateLabel.Text = "30Mbps";
            // 
            // metroLabel18
            // 
            this.metroLabel18.AutoSize = true;
            this.metroLabel18.Location = new System.Drawing.Point(533, 233);
            this.metroLabel18.Name = "metroLabel18";
            this.metroLabel18.Size = new System.Drawing.Size(51, 19);
            this.metroLabel18.TabIndex = 4;
            this.metroLabel18.Text = "2000kB";
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.Location = new System.Drawing.Point(523, 70);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(63, 19);
            this.metroLabel9.TabIndex = 4;
            this.metroLabel9.Text = "250Mbps";
            // 
            // metroLabel17
            // 
            this.metroLabel17.AutoSize = true;
            this.metroLabel17.Location = new System.Drawing.Point(161, 236);
            this.metroLabel17.Name = "metroLabel17";
            this.metroLabel17.Size = new System.Drawing.Size(42, 19);
            this.metroLabel17.TabIndex = 4;
            this.metroLabel17.Text = "100kB";
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(161, 70);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(47, 19);
            this.metroLabel8.TabIndex = 4;
            this.metroLabel8.Text = "1Mbps";
            // 
            // metroLabel16
            // 
            this.metroLabel16.AutoSize = true;
            this.metroLabel16.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel16.Location = new System.Drawing.Point(25, 240);
            this.metroLabel16.Name = "metroLabel16";
            this.metroLabel16.Size = new System.Drawing.Size(90, 25);
            this.metroLabel16.TabIndex = 3;
            this.metroLabel16.Text = "Buffer size";
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel10.Location = new System.Drawing.Point(25, 163);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(91, 25);
            this.metroLabel10.TabIndex = 3;
            this.metroLabel10.Text = "Resolution";
            // 
            // metroLabel31
            // 
            this.metroLabel31.AutoSize = true;
            this.metroLabel31.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel31.Location = new System.Drawing.Point(25, 17);
            this.metroLabel31.Name = "metroLabel31";
            this.metroLabel31.Size = new System.Drawing.Size(60, 25);
            this.metroLabel31.TabIndex = 3;
            this.metroLabel31.Text = "Codec";
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel7.Location = new System.Drawing.Point(25, 86);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(60, 25);
            this.metroLabel7.TabIndex = 3;
            this.metroLabel7.Text = "Bitrate";
            // 
            // bufferTrackBar
            // 
            this.bufferTrackBar.BackColor = System.Drawing.Color.Transparent;
            this.bufferTrackBar.DataBindings.Add(new System.Windows.Forms.Binding("Value", global::ALVR.Properties.Settings.Default, "bufferSize", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.bufferTrackBar.Location = new System.Drawing.Point(185, 258);
            this.bufferTrackBar.Name = "bufferTrackBar";
            this.bufferTrackBar.Size = new System.Drawing.Size(368, 23);
            this.bufferTrackBar.TabIndex = 2;
            this.bufferTrackBar.Text = "metroTrackBar1";
            this.bufferTrackBar.Value = global::ALVR.Properties.Settings.Default.bufferSize;
            this.bufferTrackBar.ValueChanged += new System.EventHandler(this.bufferTrackBar_ValueChanged);
            // 
            // bitrateTrackBar
            // 
            this.bitrateTrackBar.BackColor = System.Drawing.Color.Transparent;
            this.bitrateTrackBar.DataBindings.Add(new System.Windows.Forms.Binding("Value", global::ALVR.Properties.Settings.Default, "bitrate", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.bitrateTrackBar.Location = new System.Drawing.Point(185, 92);
            this.bitrateTrackBar.Maximum = 250;
            this.bitrateTrackBar.Minimum = 1;
            this.bitrateTrackBar.Name = "bitrateTrackBar";
            this.bitrateTrackBar.Size = new System.Drawing.Size(368, 23);
            this.bitrateTrackBar.TabIndex = 2;
            this.bitrateTrackBar.Text = "metroTrackBar1";
            this.bitrateTrackBar.Value = global::ALVR.Properties.Settings.Default.bitrate;
            this.bitrateTrackBar.ValueChanged += new System.EventHandler(this.bitrateTrackBar_ValueChanged);
            // 
            // soundTab
            // 
            this.soundTab.Controls.Add(this.soundDeviceComboBox);
            this.soundTab.Controls.Add(this.defaultSoundDeviceCheckBox);
            this.soundTab.Controls.Add(this.soundCheckBox);
            this.soundTab.HorizontalScrollbarBarColor = true;
            this.soundTab.Location = new System.Drawing.Point(4, 38);
            this.soundTab.Name = "soundTab";
            this.soundTab.Size = new System.Drawing.Size(656, 354);
            this.soundTab.TabIndex = 8;
            this.soundTab.Text = "Sound";
            this.soundTab.VerticalScrollbarBarColor = true;
            // 
            // soundDeviceComboBox
            // 
            this.soundDeviceComboBox.FormattingEnabled = true;
            this.soundDeviceComboBox.ItemHeight = 23;
            this.soundDeviceComboBox.Location = new System.Drawing.Point(76, 116);
            this.soundDeviceComboBox.Name = "soundDeviceComboBox";
            this.soundDeviceComboBox.Size = new System.Drawing.Size(471, 29);
            this.soundDeviceComboBox.TabIndex = 3;
            // 
            // soundCheckBox
            // 
            this.soundCheckBox.AutoSize = true;
            this.soundCheckBox.Checked = global::ALVR.Properties.Settings.Default.enableSound;
            this.soundCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.soundCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("Checked", global::ALVR.Properties.Settings.Default, "enableSound", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.soundCheckBox.Location = new System.Drawing.Point(30, 35);
            this.soundCheckBox.Name = "soundCheckBox";
            this.soundCheckBox.Size = new System.Drawing.Size(92, 15);
            this.soundCheckBox.TabIndex = 2;
            this.soundCheckBox.Text = "Steam sound";
            this.soundCheckBox.UseVisualStyleBackColor = true;
            this.soundCheckBox.CheckedChanged += new System.EventHandler(this.soundCheckBox_CheckedChanged);
            // 
            // otherTab
            // 
            this.otherTab.Controls.Add(this.trackingFrameOffsetTextBox);
            this.otherTab.Controls.Add(this.metroLabel30);
            this.otherTab.Controls.Add(this.metroLabel29);
            this.otherTab.Controls.Add(this.metroLabel28);
            this.otherTab.Controls.Add(this.metroLabel27);
            this.otherTab.Controls.Add(this.refDisconnectCommandButton);
            this.otherTab.Controls.Add(this.refConnectCommandButton);
            this.otherTab.Controls.Add(this.disconnectCommandTextBox);
            this.otherTab.Controls.Add(this.connectCommandTextBox);
            this.otherTab.Controls.Add(this.offsetPosCheckBox);
            this.otherTab.Controls.Add(this.offsetPosZTextBox);
            this.otherTab.Controls.Add(this.offsetPosYTextBox);
            this.otherTab.Controls.Add(this.offsetPosXTextBox);
            this.otherTab.Controls.Add(this.saveTrackingFrameOffsetButton);
            this.otherTab.Controls.Add(this.sendOffsetPos);
            this.otherTab.Controls.Add(this.metroLabel26);
            this.otherTab.Controls.Add(this.metroLabel25);
            this.otherTab.Controls.Add(this.metroLabel24);
            this.otherTab.Controls.Add(this.suppressFrameDropCheckBox);
            this.otherTab.Controls.Add(this.onlySteamVRCheckBox);
            this.otherTab.Controls.Add(this.fakeTrackingReferenceCheckBox);
            this.otherTab.HorizontalScrollbarBarColor = true;
            this.otherTab.Location = new System.Drawing.Point(4, 38);
            this.otherTab.Name = "otherTab";
            this.otherTab.Size = new System.Drawing.Size(656, 354);
            this.otherTab.TabIndex = 7;
            this.otherTab.Text = "Other";
            this.otherTab.VerticalScrollbar = true;
            this.otherTab.VerticalScrollbarBarColor = true;
            // 
            // trackingFrameOffsetTextBox
            // 
            this.trackingFrameOffsetTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::ALVR.Properties.Settings.Default, "trackingFrameOffset", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.trackingFrameOffsetTextBox.Location = new System.Drawing.Point(190, 255);
            this.trackingFrameOffsetTextBox.Name = "trackingFrameOffsetTextBox";
            this.trackingFrameOffsetTextBox.Size = new System.Drawing.Size(86, 23);
            this.trackingFrameOffsetTextBox.TabIndex = 19;
            this.trackingFrameOffsetTextBox.Text = global::ALVR.Properties.Settings.Default.trackingFrameOffset;
            // 
            // metroLabel30
            // 
            this.metroLabel30.AutoSize = true;
            this.metroLabel30.Location = new System.Drawing.Point(64, 290);
            this.metroLabel30.Name = "metroLabel30";
            this.metroLabel30.Size = new System.Drawing.Size(279, 38);
            this.metroLabel30.TabIndex = 18;
            this.metroLabel30.Text = "Try \"-1\" if you exceprience jerky head-tracking.\r\nPut \"0\" on if you have no probl" +
    "em.";
            // 
            // metroLabel29
            // 
            this.metroLabel29.AutoSize = true;
            this.metroLabel29.Location = new System.Drawing.Point(35, 259);
            this.metroLabel29.Name = "metroLabel29";
            this.metroLabel29.Size = new System.Drawing.Size(129, 19);
            this.metroLabel29.TabIndex = 18;
            this.metroLabel29.Text = "TrackingFrameOffset";
            // 
            // metroLabel28
            // 
            this.metroLabel28.AutoSize = true;
            this.metroLabel28.Location = new System.Drawing.Point(39, 208);
            this.metroLabel28.Name = "metroLabel28";
            this.metroLabel28.Size = new System.Drawing.Size(92, 19);
            this.metroLabel28.TabIndex = 17;
            this.metroLabel28.Text = "On disconnect";
            // 
            // metroLabel27
            // 
            this.metroLabel27.AutoSize = true;
            this.metroLabel27.Location = new System.Drawing.Point(55, 179);
            this.metroLabel27.Name = "metroLabel27";
            this.metroLabel27.Size = new System.Drawing.Size(76, 19);
            this.metroLabel27.TabIndex = 17;
            this.metroLabel27.Text = "On connect";
            // 
            // refDisconnectCommandButton
            // 
            this.refDisconnectCommandButton.Location = new System.Drawing.Point(527, 208);
            this.refDisconnectCommandButton.Name = "refDisconnectCommandButton";
            this.refDisconnectCommandButton.Size = new System.Drawing.Size(52, 23);
            this.refDisconnectCommandButton.TabIndex = 16;
            this.refDisconnectCommandButton.Text = "...";
            this.refDisconnectCommandButton.Click += new System.EventHandler(this.refDisconnectCommandButton_Click);
            // 
            // refConnectCommandButton
            // 
            this.refConnectCommandButton.Location = new System.Drawing.Point(527, 179);
            this.refConnectCommandButton.Name = "refConnectCommandButton";
            this.refConnectCommandButton.Size = new System.Drawing.Size(52, 23);
            this.refConnectCommandButton.TabIndex = 16;
            this.refConnectCommandButton.Text = "...";
            this.refConnectCommandButton.Click += new System.EventHandler(this.refConnectCommandButton_Click);
            // 
            // disconnectCommandTextBox
            // 
            this.disconnectCommandTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::ALVR.Properties.Settings.Default, "disconnectCommand", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.disconnectCommandTextBox.Location = new System.Drawing.Point(137, 208);
            this.disconnectCommandTextBox.Name = "disconnectCommandTextBox";
            this.disconnectCommandTextBox.Size = new System.Drawing.Size(383, 23);
            this.disconnectCommandTextBox.TabIndex = 15;
            this.disconnectCommandTextBox.Text = global::ALVR.Properties.Settings.Default.disconnectCommand;
            // 
            // connectCommandTextBox
            // 
            this.connectCommandTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::ALVR.Properties.Settings.Default, "connectCommand", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.connectCommandTextBox.Location = new System.Drawing.Point(137, 179);
            this.connectCommandTextBox.Name = "connectCommandTextBox";
            this.connectCommandTextBox.Size = new System.Drawing.Size(383, 23);
            this.connectCommandTextBox.TabIndex = 15;
            this.connectCommandTextBox.Text = global::ALVR.Properties.Settings.Default.connectCommand;
            // 
            // offsetPosCheckBox
            // 
            this.offsetPosCheckBox.AutoSize = true;
            this.offsetPosCheckBox.Checked = global::ALVR.Properties.Settings.Default.useOffsetPos;
            this.offsetPosCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("Checked", global::ALVR.Properties.Settings.Default, "useOffsetPos", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.offsetPosCheckBox.Location = new System.Drawing.Point(35, 79);
            this.offsetPosCheckBox.Name = "offsetPosCheckBox";
            this.offsetPosCheckBox.Size = new System.Drawing.Size(87, 15);
            this.offsetPosCheckBox.TabIndex = 14;
            this.offsetPosCheckBox.Text = "Apply offset";
            this.offsetPosCheckBox.UseVisualStyleBackColor = true;
            // 
            // offsetPosZTextBox
            // 
            this.offsetPosZTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::ALVR.Properties.Settings.Default, "offsetPosZ", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.offsetPosZTextBox.Location = new System.Drawing.Point(254, 75);
            this.offsetPosZTextBox.Name = "offsetPosZTextBox";
            this.offsetPosZTextBox.Size = new System.Drawing.Size(58, 23);
            this.offsetPosZTextBox.TabIndex = 11;
            this.offsetPosZTextBox.Text = global::ALVR.Properties.Settings.Default.offsetPosZ;
            // 
            // offsetPosYTextBox
            // 
            this.offsetPosYTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::ALVR.Properties.Settings.Default, "offsetPosY", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.offsetPosYTextBox.Location = new System.Drawing.Point(190, 75);
            this.offsetPosYTextBox.Name = "offsetPosYTextBox";
            this.offsetPosYTextBox.Size = new System.Drawing.Size(58, 23);
            this.offsetPosYTextBox.TabIndex = 12;
            this.offsetPosYTextBox.Text = global::ALVR.Properties.Settings.Default.offsetPosY;
            // 
            // offsetPosXTextBox
            // 
            this.offsetPosXTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::ALVR.Properties.Settings.Default, "offsetPosX", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.offsetPosXTextBox.Location = new System.Drawing.Point(126, 75);
            this.offsetPosXTextBox.Name = "offsetPosXTextBox";
            this.offsetPosXTextBox.Size = new System.Drawing.Size(58, 23);
            this.offsetPosXTextBox.TabIndex = 13;
            this.offsetPosXTextBox.Text = global::ALVR.Properties.Settings.Default.offsetPosX;
            // 
            // saveTrackingFrameOffsetButton
            // 
            this.saveTrackingFrameOffsetButton.Location = new System.Drawing.Point(284, 255);
            this.saveTrackingFrameOffsetButton.Name = "saveTrackingFrameOffsetButton";
            this.saveTrackingFrameOffsetButton.Size = new System.Drawing.Size(75, 23);
            this.saveTrackingFrameOffsetButton.TabIndex = 10;
            this.saveTrackingFrameOffsetButton.Text = "Save";
            this.saveTrackingFrameOffsetButton.Click += new System.EventHandler(this.saveTrackingFrameOffsetButton_Click);
            // 
            // sendOffsetPos
            // 
            this.sendOffsetPos.Location = new System.Drawing.Point(318, 75);
            this.sendOffsetPos.Name = "sendOffsetPos";
            this.sendOffsetPos.Size = new System.Drawing.Size(75, 23);
            this.sendOffsetPos.TabIndex = 10;
            this.sendOffsetPos.Text = "Save";
            this.sendOffsetPos.Click += new System.EventHandler(this.sendOffsetPos_Click);
            // 
            // metroLabel26
            // 
            this.metroLabel26.AutoSize = true;
            this.metroLabel26.Location = new System.Drawing.Point(35, 151);
            this.metroLabel26.Name = "metroLabel26";
            this.metroLabel26.Size = new System.Drawing.Size(95, 19);
            this.metroLabel26.TabIndex = 3;
            this.metroLabel26.Text = "Run command";
            // 
            // metroLabel25
            // 
            this.metroLabel25.AutoSize = true;
            this.metroLabel25.Location = new System.Drawing.Point(64, 111);
            this.metroLabel25.Name = "metroLabel25";
            this.metroLabel25.Size = new System.Drawing.Size(212, 19);
            this.metroLabel25.TabIndex = 3;
            this.metroLabel25.Text = "Add X,Y,Z offset to player position.";
            // 
            // metroLabel24
            // 
            this.metroLabel24.AutoSize = true;
            this.metroLabel24.Location = new System.Drawing.Point(64, 34);
            this.metroLabel24.Name = "metroLabel24";
            this.metroLabel24.Size = new System.Drawing.Size(238, 19);
            this.metroLabel24.TabIndex = 3;
            this.metroLabel24.Text = "Add fake base station for some games.";
            // 
            // suppressFrameDropCheckBox
            // 
            this.suppressFrameDropCheckBox.AutoSize = true;
            this.suppressFrameDropCheckBox.Checked = global::ALVR.Properties.Settings.Default.suppressFrameDrop;
            this.suppressFrameDropCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("Checked", global::ALVR.Properties.Settings.Default, "suppressFrameDrop", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.suppressFrameDropCheckBox.Location = new System.Drawing.Point(407, 59);
            this.suppressFrameDropCheckBox.Name = "suppressFrameDropCheckBox";
            this.suppressFrameDropCheckBox.Size = new System.Drawing.Size(132, 15);
            this.suppressFrameDropCheckBox.TabIndex = 2;
            this.suppressFrameDropCheckBox.Text = "Suppress frame drop";
            this.suppressFrameDropCheckBox.UseVisualStyleBackColor = true;
            this.suppressFrameDropCheckBox.CheckedChanged += new System.EventHandler(this.suppressFrameDropCheckBox_CheckedChanged);
            // 
            // onlySteamVRCheckBox
            // 
            this.onlySteamVRCheckBox.AutoSize = true;
            this.onlySteamVRCheckBox.Checked = global::ALVR.Properties.Settings.Default.onlySteamVR;
            this.onlySteamVRCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("Checked", global::ALVR.Properties.Settings.Default, "onlySteamVR", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.onlySteamVRCheckBox.Location = new System.Drawing.Point(407, 16);
            this.onlySteamVRCheckBox.Name = "onlySteamVRCheckBox";
            this.onlySteamVRCheckBox.Size = new System.Drawing.Size(221, 15);
            this.onlySteamVRCheckBox.TabIndex = 2;
            this.onlySteamVRCheckBox.Text = "Launch only SteamVR without Steam.";
            this.onlySteamVRCheckBox.UseVisualStyleBackColor = true;
            // 
            // fakeTrackingReferenceCheckBox
            // 
            this.fakeTrackingReferenceCheckBox.AutoSize = true;
            this.fakeTrackingReferenceCheckBox.Checked = global::ALVR.Properties.Settings.Default.useTrackingReference;
            this.fakeTrackingReferenceCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("Checked", global::ALVR.Properties.Settings.Default, "useTrackingReference", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.fakeTrackingReferenceCheckBox.Location = new System.Drawing.Point(35, 16);
            this.fakeTrackingReferenceCheckBox.Name = "fakeTrackingReferenceCheckBox";
            this.fakeTrackingReferenceCheckBox.Size = new System.Drawing.Size(113, 15);
            this.fakeTrackingReferenceCheckBox.TabIndex = 2;
            this.fakeTrackingReferenceCheckBox.Text = "Fake base station";
            this.fakeTrackingReferenceCheckBox.UseVisualStyleBackColor = true;
            // 
            // debugTab
            // 
            this.debugTab.Controls.Add(this.metroLabel5);
            this.debugTab.Controls.Add(this.logText);
            this.debugTab.Controls.Add(this.metroCheckBox3);
            this.debugTab.Controls.Add(this.metroCheckBox2);
            this.debugTab.Controls.Add(this.debugCaptureOutputCheckBox);
            this.debugTab.Controls.Add(this.debugLogCheckBox);
            this.debugTab.Controls.Add(this.metroCheckBox1);
            this.debugTab.Controls.Add(this.metroTextBox2);
            this.debugTab.Controls.Add(this.metroTextBox1);
            this.debugTab.Controls.Add(this.metroLabel2);
            this.debugTab.Controls.Add(this.metroLabel1);
            this.debugTab.Controls.Add(this.metroButton5);
            this.debugTab.Controls.Add(this.packetlossButton);
            this.debugTab.Controls.Add(this.metroButton4);
            this.debugTab.Controls.Add(this.captureLayerDDSButton);
            this.debugTab.Controls.Add(this.captureComposedDDSButton);
            this.debugTab.Controls.Add(this.metroButton2);
            this.debugTab.Controls.Add(this.metroButton1);
            this.debugTab.HorizontalScrollbarBarColor = true;
            this.debugTab.Location = new System.Drawing.Point(4, 38);
            this.debugTab.Name = "debugTab";
            this.debugTab.Size = new System.Drawing.Size(656, 354);
            this.debugTab.TabIndex = 2;
            this.debugTab.Text = "Debug";
            this.debugTab.VerticalScrollbarBarColor = true;
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.CustomForeColor = true;
            this.metroLabel5.ForeColor = System.Drawing.Color.Red;
            this.metroLabel5.Location = new System.Drawing.Point(88, 20);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(148, 19);
            this.metroLabel5.TabIndex = 11;
            this.metroLabel5.Text = "Do not touch this panel!";
            // 
            // logText
            // 
            this.logText.Location = new System.Drawing.Point(384, 11);
            this.logText.Multiline = true;
            this.logText.Name = "logText";
            this.logText.ReadOnly = true;
            this.logText.Size = new System.Drawing.Size(253, 340);
            this.logText.TabIndex = 10;
            // 
            // metroCheckBox3
            // 
            this.metroCheckBox3.AutoSize = true;
            this.metroCheckBox3.Location = new System.Drawing.Point(281, 209);
            this.metroCheckBox3.Name = "metroCheckBox3";
            this.metroCheckBox3.Size = new System.Drawing.Size(56, 15);
            this.metroCheckBox3.TabIndex = 9;
            this.metroCheckBox3.Text = "Mutex";
            this.metroCheckBox3.UseVisualStyleBackColor = true;
            this.metroCheckBox3.CheckedChanged += new System.EventHandler(this.metroCheckBox3_CheckedChanged);
            // 
            // metroCheckBox2
            // 
            this.metroCheckBox2.AutoSize = true;
            this.metroCheckBox2.Location = new System.Drawing.Point(156, 209);
            this.metroCheckBox2.Name = "metroCheckBox2";
            this.metroCheckBox2.Size = new System.Drawing.Size(68, 15);
            this.metroCheckBox2.TabIndex = 9;
            this.metroCheckBox2.Text = "Suspend";
            this.metroCheckBox2.UseVisualStyleBackColor = true;
            this.metroCheckBox2.CheckedChanged += new System.EventHandler(this.metroCheckBox2_CheckedChanged);
            // 
            // debugCaptureOutputCheckBox
            // 
            this.debugCaptureOutputCheckBox.AutoSize = true;
            this.debugCaptureOutputCheckBox.Checked = global::ALVR.Properties.Settings.Default.debugCaptureOutput;
            this.debugCaptureOutputCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("Checked", global::ALVR.Properties.Settings.Default, "debugCaptureOutput", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.debugCaptureOutputCheckBox.Location = new System.Drawing.Point(7, 209);
            this.debugCaptureOutputCheckBox.Name = "debugCaptureOutputCheckBox";
            this.debugCaptureOutputCheckBox.Size = new System.Drawing.Size(138, 15);
            this.debugCaptureOutputCheckBox.TabIndex = 9;
            this.debugCaptureOutputCheckBox.Text = "DebugCaptureOutput";
            this.debugCaptureOutputCheckBox.UseVisualStyleBackColor = true;
            // 
            // debugLogCheckBox
            // 
            this.debugLogCheckBox.AutoSize = true;
            this.debugLogCheckBox.Checked = global::ALVR.Properties.Settings.Default.debugLog;
            this.debugLogCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("Checked", global::ALVR.Properties.Settings.Default, "debugLog", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.debugLogCheckBox.Location = new System.Drawing.Point(7, 177);
            this.debugLogCheckBox.Name = "debugLogCheckBox";
            this.debugLogCheckBox.Size = new System.Drawing.Size(78, 15);
            this.debugLogCheckBox.TabIndex = 9;
            this.debugLogCheckBox.Text = "DebugLog";
            this.debugLogCheckBox.UseVisualStyleBackColor = true;
            // 
            // metroCheckBox1
            // 
            this.metroCheckBox1.AutoSize = true;
            this.metroCheckBox1.Location = new System.Drawing.Point(156, 177);
            this.metroCheckBox1.Name = "metroCheckBox1";
            this.metroCheckBox1.Size = new System.Drawing.Size(119, 15);
            this.metroCheckBox1.TabIndex = 9;
            this.metroCheckBox1.Text = "DebugFrameIndex";
            this.metroCheckBox1.UseVisualStyleBackColor = true;
            // 
            // metroTextBox2
            // 
            this.metroTextBox2.Location = new System.Drawing.Point(159, 104);
            this.metroTextBox2.Name = "metroTextBox2";
            this.metroTextBox2.Size = new System.Drawing.Size(116, 23);
            this.metroTextBox2.TabIndex = 8;
            this.metroTextBox2.Text = "0";
            // 
            // metroTextBox1
            // 
            this.metroTextBox1.Location = new System.Drawing.Point(159, 62);
            this.metroTextBox1.Name = "metroTextBox1";
            this.metroTextBox1.Size = new System.Drawing.Size(116, 23);
            this.metroTextBox1.TabIndex = 8;
            this.metroTextBox1.Text = "0";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(1, 108);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(139, 19);
            this.metroLabel2.TabIndex = 7;
            this.metroLabel2.Text = "EnableDriverTestMode";
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(1, 67);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(104, 19);
            this.metroLabel1.TabIndex = 7;
            this.metroLabel1.Text = "EnableTestMode";
            // 
            // metroButton5
            // 
            this.metroButton5.Location = new System.Drawing.Point(281, 177);
            this.metroButton5.Name = "metroButton5";
            this.metroButton5.Size = new System.Drawing.Size(75, 23);
            this.metroButton5.TabIndex = 6;
            this.metroButton5.Text = "Send";
            this.metroButton5.Click += new System.EventHandler(this.metroButton5_Click);
            // 
            // packetlossButton
            // 
            this.packetlossButton.Location = new System.Drawing.Point(250, 230);
            this.packetlossButton.Name = "packetlossButton";
            this.packetlossButton.Size = new System.Drawing.Size(106, 23);
            this.packetlossButton.TabIndex = 6;
            this.packetlossButton.Text = "Cause packet loss";
            this.packetlossButton.Click += new System.EventHandler(this.packetlossButton_Click);
            // 
            // metroButton4
            // 
            this.metroButton4.Location = new System.Drawing.Point(70, 148);
            this.metroButton4.Name = "metroButton4";
            this.metroButton4.Size = new System.Drawing.Size(75, 23);
            this.metroButton4.TabIndex = 6;
            this.metroButton4.Text = "GetConfig";
            this.metroButton4.Click += new System.EventHandler(this.metroButton4_Click);
            // 
            // captureLayerDDSButton
            // 
            this.captureLayerDDSButton.Location = new System.Drawing.Point(156, 148);
            this.captureLayerDDSButton.Name = "captureLayerDDSButton";
            this.captureLayerDDSButton.Size = new System.Drawing.Size(96, 23);
            this.captureLayerDDSButton.TabIndex = 6;
            this.captureLayerDDSButton.Text = "Capture Layer";
            this.captureLayerDDSButton.Click += new System.EventHandler(this.captureLayerDDSButton_Click);
            // 
            // aboutTab
            // 
            this.aboutTab.Controls.Add(this.driverLabel);
            this.aboutTab.Controls.Add(this.uninstallButton);
            this.aboutTab.Controls.Add(this.listDriversButton);
            this.aboutTab.Controls.Add(this.installButton);
            this.aboutTab.Controls.Add(this.metroLabel15);
            this.aboutTab.Controls.Add(this.metroLabel14);
            this.aboutTab.Controls.Add(this.licenseTextBox);
            this.aboutTab.Controls.Add(this.versionLabel);
            this.aboutTab.Controls.Add(this.metroLabel6);
            this.aboutTab.HorizontalScrollbarBarColor = true;
            this.aboutTab.Location = new System.Drawing.Point(4, 38);
            this.aboutTab.Name = "aboutTab";
            this.aboutTab.Size = new System.Drawing.Size(656, 354);
            this.aboutTab.TabIndex = 4;
            this.aboutTab.Text = "About";
            this.aboutTab.VerticalScrollbarBarColor = true;
            // 
            // driverLabel
            // 
            this.driverLabel.AutoSize = true;
            this.driverLabel.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.driverLabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.driverLabel.Location = new System.Drawing.Point(91, 265);
            this.driverLabel.Name = "driverLabel";
            this.driverLabel.Size = new System.Drawing.Size(138, 19);
            this.driverLabel.Style = MetroFramework.MetroColorStyle.Green;
            this.driverLabel.TabIndex = 6;
            this.driverLabel.Text = "Driver is not installed";
            this.driverLabel.UseStyleColors = true;
            // 
            // uninstallButton
            // 
            this.uninstallButton.Location = new System.Drawing.Point(164, 296);
            this.uninstallButton.Name = "uninstallButton";
            this.uninstallButton.Size = new System.Drawing.Size(109, 23);
            this.uninstallButton.TabIndex = 5;
            this.uninstallButton.Text = "Uninstall driver";
            this.uninstallButton.Click += new System.EventHandler(this.uninstallButton_Click);
            // 
            // listDriversButton
            // 
            this.listDriversButton.Location = new System.Drawing.Point(107, 328);
            this.listDriversButton.Name = "listDriversButton";
            this.listDriversButton.Size = new System.Drawing.Size(98, 23);
            this.listDriversButton.TabIndex = 5;
            this.listDriversButton.Text = "List drivers";
            this.listDriversButton.Click += new System.EventHandler(this.listDriversButton_Click);
            // 
            // installButton
            // 
            this.installButton.Location = new System.Drawing.Point(46, 296);
            this.installButton.Name = "installButton";
            this.installButton.Size = new System.Drawing.Size(98, 23);
            this.installButton.TabIndex = 5;
            this.installButton.Text = "Install driver";
            this.installButton.Click += new System.EventHandler(this.installButton_Click);
            // 
            // metroLabel15
            // 
            this.metroLabel15.AutoSize = true;
            this.metroLabel15.Location = new System.Drawing.Point(308, 15);
            this.metroLabel15.Name = "metroLabel15";
            this.metroLabel15.Size = new System.Drawing.Size(125, 19);
            this.metroLabel15.TabIndex = 4;
            this.metroLabel15.Text = "Opensource license:";
            // 
            // metroLabel14
            // 
            this.metroLabel14.AutoSize = true;
            this.metroLabel14.Location = new System.Drawing.Point(31, 51);
            this.metroLabel14.Name = "metroLabel14";
            this.metroLabel14.Size = new System.Drawing.Size(213, 19);
            this.metroLabel14.TabIndex = 4;
            this.metroLabel14.Text = "The opensource remote VR display";
            // 
            // licenseTextBox
            // 
            this.licenseTextBox.Location = new System.Drawing.Point(308, 37);
            this.licenseTextBox.Multiline = true;
            this.licenseTextBox.Name = "licenseTextBox";
            this.licenseTextBox.ReadOnly = true;
            this.licenseTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.licenseTextBox.Size = new System.Drawing.Size(335, 314);
            this.licenseTextBox.TabIndex = 3;
            // 
            // versionLabel
            // 
            this.versionLabel.AutoSize = true;
            this.versionLabel.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.versionLabel.Location = new System.Drawing.Point(73, 15);
            this.versionLabel.Name = "versionLabel";
            this.versionLabel.Size = new System.Drawing.Size(39, 25);
            this.versionLabel.TabIndex = 2;
            this.versionLabel.Text = "v1.0";
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel6.Location = new System.Drawing.Point(17, 15);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(50, 25);
            this.metroLabel6.TabIndex = 2;
            this.metroLabel6.Text = "ALVR";
            // 
            // metroLabel3
            // 
            this.metroLabel3.CustomBackground = true;
            this.metroLabel3.CustomForeColor = true;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel3.Location = new System.Drawing.Point(517, 29);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(115, 39);
            this.metroLabel3.TabIndex = 9;
            this.metroLabel3.Text = "metroLabel3";
            this.metroLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // startServerButton
            // 
            this.startServerButton.Location = new System.Drawing.Point(376, 32);
            this.startServerButton.Name = "startServerButton";
            this.startServerButton.Size = new System.Drawing.Size(75, 36);
            this.startServerButton.TabIndex = 10;
            this.startServerButton.Text = "Start server";
            this.startServerButton.Click += new System.EventHandler(this.metroButton6_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ALVR.Properties.Resources.alvr_128;
            this.pictureBox1.Location = new System.Drawing.Point(93, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 48);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // defaultSoundDeviceCheckBox
            // 
            this.defaultSoundDeviceCheckBox.AutoSize = true;
            this.defaultSoundDeviceCheckBox.Checked = global::ALVR.Properties.Settings.Default.useDefaultSoundDevice;
            this.defaultSoundDeviceCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.defaultSoundDeviceCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("Checked", global::ALVR.Properties.Settings.Default, "useDefaultSoundDevice", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.defaultSoundDeviceCheckBox.Location = new System.Drawing.Point(53, 77);
            this.defaultSoundDeviceCheckBox.Name = "defaultSoundDeviceCheckBox";
            this.defaultSoundDeviceCheckBox.Size = new System.Drawing.Size(119, 15);
            this.defaultSoundDeviceCheckBox.TabIndex = 2;
            this.defaultSoundDeviceCheckBox.Text = "Use default device";
            this.defaultSoundDeviceCheckBox.UseVisualStyleBackColor = true;
            this.defaultSoundDeviceCheckBox.CheckedChanged += new System.EventHandler(this.defaultSoundDeviceCheckBox_CheckedChanged);
            // 
            // Launcher
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(710, 482);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.startServerButton);
            this.Controls.Add(this.metroProgressSpinner1);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroTabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Launcher";
            this.Text = "ALVR";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Launcher_FormClosed);
            this.Load += new System.EventHandler(this.Launcher_Load);
            this.metroTabControl1.ResumeLayout(false);
            this.serverTab.ResumeLayout(false);
            this.findingPanel.ResumeLayout(false);
            this.findingPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.connectedPanel.ResumeLayout(false);
            this.connectedPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.statDataGridView)).EndInit();
            this.messagePanel.ResumeLayout(false);
            this.controllerTab.ResumeLayout(false);
            this.controllerTab.PerformLayout();
            this.videoTab.ResumeLayout(false);
            this.videoTab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.resolutionBindingSource)).EndInit();
            this.soundTab.ResumeLayout(false);
            this.soundTab.PerformLayout();
            this.otherTab.ResumeLayout(false);
            this.otherTab.PerformLayout();
            this.debugTab.ResumeLayout(false);
            this.debugTab.PerformLayout();
            this.aboutTab.ResumeLayout(false);
            this.aboutTab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroButton metroButton1;
        private MetroFramework.Controls.MetroButton metroButton2;
        private MetroFramework.Controls.MetroProgressSpinner metroProgressSpinner1;
        private MetroFramework.Controls.MetroButton captureComposedDDSButton;
        private MetroFramework.Controls.MetroTabControl metroTabControl1;
        private MetroFramework.Controls.MetroTabPage debugTab;
        private MetroFramework.Controls.MetroTextBox metroTextBox2;
        private MetroFramework.Controls.MetroTextBox metroTextBox1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroButton metroButton4;
        private MetroFramework.Controls.MetroCheckBox metroCheckBox1;
        private MetroFramework.Controls.MetroButton metroButton5;
        private MetroFramework.Controls.MetroCheckBox metroCheckBox2;
        private MetroFramework.Controls.MetroCheckBox metroCheckBox3;
        private MetroFramework.Controls.MetroTextBox logText;
        private MetroFramework.Controls.MetroButton startServerButton;
        private MetroFramework.Controls.MetroTabPage serverTab;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Timer timer1;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroProgressSpinner metroProgressSpinner2;
        private MetroFramework.Controls.MetroLabel messageLabel;
        private MetroFramework.Controls.MetroPanel findingPanel;
        private MetroFramework.Controls.MetroPanel messagePanel;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroTabPage aboutTab;
        private MetroFramework.Controls.MetroTextBox licenseTextBox;
        private MetroFramework.Controls.MetroLabel versionLabel;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroTabPage videoTab;
        private MetroFramework.Controls.MetroLabel bitrateLabel;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroTrackBar bitrateTrackBar;
        private MetroFramework.Controls.MetroComboBox resolutionComboBox;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private MetroFramework.Controls.MetroLabel noClientLabel;
        private MetroFramework.Controls.MetroLabel metroLabel12;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private MetroFramework.Controls.MetroLabel metroLabel13;
        private System.Windows.Forms.PictureBox pictureBox1;
        private MetroFramework.Controls.MetroLabel metroLabel14;
        private MetroFramework.Controls.MetroLabel metroLabel15;
        private System.Windows.Forms.Label label1;
        private MetroFramework.Controls.MetroLabel bufferLabel;
        private MetroFramework.Controls.MetroLabel metroLabel18;
        private MetroFramework.Controls.MetroLabel metroLabel17;
        private MetroFramework.Controls.MetroLabel metroLabel16;
        private MetroFramework.Controls.MetroTrackBar bufferTrackBar;
        private System.Windows.Forms.Label label2;
        private MetroFramework.Controls.MetroLabel metroLabel19;
        private MetroFramework.Controls.MetroCheckBox debugLogCheckBox;
        private MetroFramework.Controls.MetroLabel driverLabel;
        private MetroFramework.Controls.MetroButton uninstallButton;
        private MetroFramework.Controls.MetroButton installButton;
        private MetroFramework.Controls.MetroTabPage controllerTab;
        private MetroFramework.Controls.MetroComboBox trackpadClickComboBox;
        private MetroFramework.Controls.MetroLabel metroLabel20;
        private MetroFramework.Controls.MetroComboBox triggerComboBox;
        private MetroFramework.Controls.MetroLabel metroLabel21;
        private MetroFramework.Controls.MetroLabel metroLabel22;
        private MetroFramework.Controls.MetroComboBox recenterButtonComboBox;
        private MetroFramework.Controls.MetroLabel metroLabel23;
        private System.Windows.Forms.DataGridViewTextBoxColumn NameColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn AddressColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn refreshRateColumn;
        private System.Windows.Forms.DataGridViewButtonColumn Button;
        private MetroFramework.Controls.MetroPanel connectedPanel;
        private System.Windows.Forms.DataGridView statDataGridView;
        private MetroFramework.Controls.MetroButton disconnectButton;
        private MetroFramework.Controls.MetroLabel connectedLabel;
        private System.Windows.Forms.DataGridViewTextBoxColumn Name1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Value1;
        private MetroFramework.Controls.MetroButton packetlossButton;
        private MetroFramework.Controls.MetroCheckBox enableControllerCheckBox;
        private MetroFramework.Controls.MetroTabPage otherTab;
        private MetroFramework.Controls.MetroCheckBox fakeTrackingReferenceCheckBox;
        private MetroFramework.Controls.MetroLabel metroLabel24;
        private MetroFramework.Controls.MetroButton listDriversButton;
        private System.Windows.Forms.BindingSource resolutionBindingSource;
        private MetroFramework.Controls.MetroCheckBox autoConnectCheckBox;
        private MetroFramework.Controls.MetroCheckBox debugCaptureOutputCheckBox;
        private MetroFramework.Controls.MetroCheckBox offsetPosCheckBox;
        private MetroFramework.Controls.MetroTextBox offsetPosZTextBox;
        private MetroFramework.Controls.MetroTextBox offsetPosYTextBox;
        private MetroFramework.Controls.MetroTextBox offsetPosXTextBox;
        private MetroFramework.Controls.MetroButton sendOffsetPos;
        private MetroFramework.Controls.MetroLabel metroLabel25;
        private MetroFramework.Controls.MetroLabel metroLabel28;
        private MetroFramework.Controls.MetroLabel metroLabel27;
        private MetroFramework.Controls.MetroButton refDisconnectCommandButton;
        private MetroFramework.Controls.MetroButton refConnectCommandButton;
        private MetroFramework.Controls.MetroTextBox disconnectCommandTextBox;
        private MetroFramework.Controls.MetroTextBox connectCommandTextBox;
        private MetroFramework.Controls.MetroLabel metroLabel26;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private MetroFramework.Controls.MetroTabPage soundTab;
        private MetroFramework.Controls.MetroComboBox soundDeviceComboBox;
        private MetroFramework.Controls.MetroCheckBox soundCheckBox;
        private MetroFramework.Controls.MetroTextBox trackingFrameOffsetTextBox;
        private MetroFramework.Controls.MetroLabel metroLabel30;
        private MetroFramework.Controls.MetroLabel metroLabel29;
        private MetroFramework.Controls.MetroButton saveTrackingFrameOffsetButton;
        private System.Windows.Forms.Label label3;
        private MetroFramework.Controls.MetroComboBox codecComboBox;
        private MetroFramework.Controls.MetroLabel metroLabel31;
        private MetroFramework.Controls.MetroLabel metroLabel32;
        private MetroFramework.Controls.MetroCheckBox onlySteamVRCheckBox;
        private MetroFramework.Controls.MetroCheckBox suppressFrameDropCheckBox;
        private MetroFramework.Controls.MetroComboBox backComboBox;
        private MetroFramework.Controls.MetroLabel metroLabel33;
        private MetroFramework.Controls.MetroButton captureLayerDDSButton;
        private MetroFramework.Controls.MetroCheckBox defaultSoundDeviceCheckBox;
    }
}

