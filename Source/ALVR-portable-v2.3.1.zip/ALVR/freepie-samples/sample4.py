alvr.override_head_position = True

alvr.head_position[0] = freePieIO[0].x * 10
alvr.head_position[1] = freePieIO[0].y * 10
alvr.head_position[2] = freePieIO[0].z * 10

